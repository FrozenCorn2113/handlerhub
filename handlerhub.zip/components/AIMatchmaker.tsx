
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Icons, SAMPLE_HANDLERS } from '../constants';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const AIMatchmaker: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setIsLoading(true);
    setResponse(null);

    try {
      const prompt = `
        You are an expert dog show consultant for HandlerHub. 
        The user is looking for a handler with this request: "${query}".
        
        Here is our current roster of top handlers:
        ${JSON.stringify(SAMPLE_HANDLERS, null, 2)}
        
        Based on the user's query, recommend the best match from the roster. 
        Explain why they are a good fit based on their specialties, location, or experience.
        If no one is a perfect match, suggest the closest one and explain why.
        Keep the tone professional, encouraging, and concise (under 100 words).
        Return the response in Markdown.
      `;

      const result = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [{ parts: [{ text: prompt }] }],
      });

      setResponse(result.text || "I couldn't find a specific recommendation. Please try broadening your search criteria.");
    } catch (error) {
      console.error("AI Error:", error);
      setResponse("Our AI scout is currently at a show. Please try again in a moment.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl w-80 md:w-96 overflow-hidden flex flex-col animate-in slide-in-from-bottom-4 duration-300">
          <header className="bg-primary p-4 text-white flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Icons.ShieldCheck className="w-5 h-5" />
              <span className="font-bold text-sm">AI Matchmaker</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded">
              <Icons.ChevronRight className="w-5 h-5 rotate-90" />
            </button>
          </header>
          
          <div className="p-4 flex-1 flex flex-col gap-4 max-h-[400px] overflow-y-auto custom-scrollbar">
            {!response && !isLoading && (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tell me what you're looking for (e.g., "I need a Golden Retriever expert in the Northeast for a winter show").
              </p>
            )}
            
            {isLoading && (
              <div className="flex flex-col items-center justify-center py-8 gap-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
                <span className="text-xs font-medium text-slate-400 italic">Scanning our elite roster...</span>
              </div>
            )}

            {response && (
              <div className="prose prose-sm dark:prose-invert text-slate-700 dark:text-slate-300 text-sm leading-relaxed">
                {response}
              </div>
            )}
          </div>

          <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex gap-2">
              <input 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Ask our AI..." 
                className="flex-1 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-primary outline-none"
              />
              <button 
                onClick={handleSearch}
                disabled={isLoading}
                className="bg-primary text-white p-2 rounded-lg hover:brightness-110 disabled:opacity-50"
              >
                <Icons.Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-primary text-white p-4 rounded-full shadow-xl hover:scale-105 transition-transform group relative"
        >
          <div className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
          </div>
          <Icons.MessageCircle className="w-6 h-6" />
          <span className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-slate-900 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            Find the perfect match with AI
          </span>
        </button>
      )}
    </div>
  );
};

export default AIMatchmaker;
