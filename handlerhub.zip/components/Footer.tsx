
import React from 'react';
import { Icons } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-background-dark py-12">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="bg-slate-200 dark:bg-slate-800 p-1.5 rounded-lg text-slate-600 dark:text-slate-400">
            <Icons.Dog className="w-5 h-5" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white uppercase">HandlerHub</span>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Connecting champions with the people who make them shine.</p>
        <div className="flex justify-center gap-8 text-sm font-medium text-slate-600 dark:text-slate-400">
          <a className="hover:text-primary" href="#">Help Center</a>
          <a className="hover:text-primary" href="#">Terms of Service</a>
          <a className="hover:text-primary" href="#">Privacy Policy</a>
          <a className="hover:text-primary" href="#">Contact</a>
        </div>
        <div className="mt-8 text-xs text-slate-400">
          © 2024 HandlerHub Marketplace. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
