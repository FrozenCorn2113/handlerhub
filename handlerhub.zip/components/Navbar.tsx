
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Icons } from '../constants';

const Navbar: React.FC = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === '/onboarding';

  if (isAuthPage) return (
    // Fixed: Changed 'class' to 'className' for standard React element properties
    <header className="w-full border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-background-dark/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-primary p-1.5 rounded-lg">
            <Icons.Dog className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold text-gray-900 dark:text-white">HandlerHub</span>
        </Link>
        <button className="text-sm font-medium text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white transition-colors">
          Save & Exit
        </button>
      </div>
    </header>
  );

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2 cursor-pointer">
              <div className="bg-primary p-1.5 rounded-lg text-white">
                <Icons.Dog className="w-6 h-6" />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white leading-none">HandlerHub</span>
            </Link>
            <div className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link to="/search" className="hover:text-primary transition-colors">Find Handlers</Link>
              <Link to="/messaging" className="hover:text-primary transition-colors">Messages</Link>
              <Link to="/onboarding" className="hover:text-primary transition-colors">Become a Handler</Link>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden sm:block">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Icons.Search className="w-4 h-4" />
              </span>
              <input 
                className="w-64 pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-lg text-sm focus:ring-2 focus:ring-primary" 
                placeholder="Search shows or breeds..." 
                type="text" 
              />
            </div>
            <button className="p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
              <Icons.Bell className="w-5 h-5" />
            </button>
            <div className="h-8 w-8 rounded-full bg-cover bg-center border border-slate-200" 
                 style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDKaroJOXeJa2MvjJtSW1F2WWFPslefRUEV1iPE34WKyH_rOIXIBlfm6f1dadtZN8gevQaWjIBi0kA779B4SG4xt1NF0HlJ4CfxFz7WOHo_N_1ycd4biLRVHCw56G1la9vkaMFGOKoNbXU7P6Shv8RPLAkO2NxllqiZMPB89EiVPxw-18RrT2UNM5EioEydl3cvJnpyQfWl8xqaSO7kbZUjliCJM-qVJBjhwnGJ_t0vyGMjm27RZPheZlft0HtV0DelZszlhXyX8A')" }}>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
