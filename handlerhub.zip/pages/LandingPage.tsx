
import React from 'react';
import { Link } from 'react-router-dom';
import { Icons } from '../constants';

const LandingPage: React.FC = () => {
  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <section className="relative w-full overflow-hidden py-12 lg:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="relative z-10 grid lg:grid-cols-2 gap-12 items-center">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider mb-6">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                New: Verified Specialty Handlers
              </div>
              <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl leading-tight text-slate-900 dark:text-white mb-6">
                Professional dog handling, without the <span className="text-primary italic">chaos</span>.
              </h1>
              <p className="text-lg md:text-xl text-slate-600 dark:text-slate-400 mb-10 leading-relaxed">
                Find verified, breed-specific handlers for your next show in minutes. Skip the noisy Facebook groups and connect with the industry's best talent.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/search" className="bg-primary text-white font-bold h-14 px-8 rounded-lg text-lg flex items-center justify-center gap-2 hover:shadow-lg hover:-translate-y-0.5 transition-all">
                  Find a Handler
                  <Icons.Search className="w-5 h-5" />
                </Link>
                <Link to="/onboarding" className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white font-bold h-14 px-8 rounded-lg text-lg flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-700 transition-all">
                  Become a Handler
                </Link>
              </div>
            </div>
            <div className="relative lg:block hidden">
              <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl bg-slate-200 relative group">
                <img 
                  alt="Professional dog handler at show" 
                  className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuB27lNRCgmjiiTv0g_YlATZMWLDDJulSx5sR6swWb7kjUrpx_LUMzHpqOOMDWuCaNfuew6hjM9lSvEfZUi35G1KpF7RX5AFbEFX-ITmhLm233P61eMAea453ZgleE5l4C2qwOQ-a_TPuu4rAqf4Pd7r14zyXLeknA1f5zNL2nKaKgDhacZucp2puzWVLcf6vk5Qr5aiVwBYt3rt4ej0bUZkJqB8wAO7Bx1p9FDFuY2YUTg-RGF-ej8hoWEXIlrLT5PFviprVdx1Kg" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 p-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur rounded-xl shadow-xl">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-slate-300 overflow-hidden">
                      <img alt="User" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRONK-IhEutRCGNZkXQgeT-UMTcMQ7WQ6NTBZbjO_i7kVDCu1tvE6V6EAXLluDDnVVKXHZXZtve1HctfwORjWvNvGuRgjEkkmYwxc44gcaJwopSJojveEX3yzaSKujLrkU9qcSvi1Uhv4dZDyVDGdfJP82qKR9ua8-dt64a1vgviZgr9YTc10NhApZCv39oKHE_AILWgbXUtGZvjJxCycwClTX8Cwl2Vy6odxqpCCMEZMAFKtThTHnHiMiiSs5H6NpsesZYi7syg" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">Marcus Thorne</p>
                      <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">AKC Registered Handler</p>
                    </div>
                    <div className="ml-auto flex text-yellow-500">
                      {[...Array(5)].map((_, i) => <Icons.Star key={i} className="w-4 h-4 fill-current" />)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Signals */}
      <section className="bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center md:text-left">
            <div className="flex flex-col items-center md:items-start gap-2">
              <div className="flex items-center gap-3 text-primary mb-1">
                <Icons.ShieldCheck className="w-8 h-8" />
                <span className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">500+</span>
              </div>
              <p className="text-sm font-bold uppercase tracking-widest text-slate-500">Verified Handlers</p>
              <p className="text-slate-400 text-xs">Every handler passes a rigorous experience check.</p>
            </div>
            <div className="flex flex-col items-center md:items-start gap-2 border-slate-200 dark:border-slate-800 md:border-x md:px-12">
              <div className="flex items-center gap-3 text-primary mb-1">
                <Icons.Dog className="w-8 h-8" />
                <span className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">100+</span>
              </div>
              <p className="text-sm font-bold uppercase tracking-widest text-slate-500">AKC Breeds</p>
              <p className="text-slate-400 text-xs">Specialized expertise across all seven show groups.</p>
            </div>
            <div className="flex flex-col items-center md:items-start gap-2">
              <div className="flex items-center gap-3 text-primary mb-1">
                <Icons.Star className="w-8 h-8 fill-current" />
                <span className="text-3xl font-black tracking-tight text-slate-900 dark:text-white">4.9/5</span>
              </div>
              <p className="text-sm font-bold uppercase tracking-widest text-slate-500">Average Rating</p>
              <p className="text-slate-400 text-xs">Consistent quality performance and client care.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="relative bg-primary rounded-[2.5rem] overflow-hidden p-8 md:p-16 lg:p-24">
            <div className="absolute inset-0 bg-gradient-to-br from-primary via-blue-600 to-indigo-700 opacity-90"></div>
            <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="font-serif text-4xl md:text-5xl text-white leading-tight mb-8">
                  Ready to show your dog's true potential?
                </h2>
                <p className="text-white/80 text-lg mb-12 leading-relaxed max-w-lg">
                  Join thousands of owners who trust HandlerHub to find the perfect professional partners for their canine athletes.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link to="/search" className="bg-white text-primary font-black px-10 py-5 rounded-xl hover:shadow-2xl transition-all">
                    Browse Handlers Now
                  </Link>
                  <button className="bg-transparent border-2 border-white/30 hover:border-white text-white font-bold px-10 py-5 rounded-xl transition-all">
                    Contact Support
                  </button>
                </div>
              </div>
              <div className="hidden lg:grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10">
                    <Icons.Calendar className="text-white w-8 h-8 mb-2" />
                    <p className="text-white font-bold">Auto-Sync Schedule</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10">
                    <Icons.Award className="text-white w-8 h-8 mb-2" />
                    <p className="text-white font-bold">Secure Escrow</p>
                  </div>
                </div>
                <div className="space-y-4 mt-8">
                  <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10">
                    <Icons.Briefcase className="text-white w-8 h-8 mb-2" />
                    <p className="text-white font-bold">E-Contracts</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur p-6 rounded-2xl border border-white/10">
                    <Icons.Bell className="text-white w-8 h-8 mb-2" />
                    <p className="text-white font-bold">Real-time Alerts</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
