
import React, { useState } from 'react';
import { Icons } from '../constants';

const MessagingPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('Sarah Jenkins');

  return (
    <div className="flex h-[calc(100vh-64px)] overflow-hidden animate-fade-in">
      {/* Sidebar: Conversations */}
      <aside className="w-80 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800">
          <div className="relative">
            <Icons.Search className="absolute left-3 top-2.5 text-slate-400 w-4 h-4" />
            <input 
              className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-primary/50 transition-all" 
              placeholder="Search conversations..." 
              type="text" 
            />
          </div>
        </div>
        <div className="overflow-y-auto flex-1 custom-scrollbar">
          {['Sarah Jenkins', 'Michael Chen', 'Linda Wu'].map((name, i) => (
            <div 
              key={name}
              onClick={() => setActiveTab(name)}
              className={`flex items-center gap-3 p-4 cursor-pointer transition-colors border-b border-slate-50 dark:border-slate-800/50 ${activeTab === name ? 'bg-primary/5 border-r-4 border-primary' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'}`}
            >
              <div className="relative">
                <div className="bg-slate-200 rounded-full size-12 bg-cover bg-center" style={{ backgroundImage: `url('https://picsum.photos/200/200?random=${i}')` }}></div>
                {i === 0 && <div className="absolute bottom-0 right-0 size-3 bg-green-500 border-2 border-white rounded-full"></div>}
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="flex justify-between items-center mb-0.5">
                  <h4 className="font-semibold text-sm truncate">{name}</h4>
                  <span className="text-[10px] text-slate-500 uppercase font-bold">10:45 AM</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 truncate font-medium">Re: Westminster Dog Show...</p>
                <div className="mt-1">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
                    {i === 0 ? 'Inquiry' : 'Negotiating'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Main Chat Area */}
      <section className="flex-1 flex flex-col bg-white dark:bg-slate-900">
        <header className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
              <Icons.Trophy className="text-primary w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-none">{activeTab}</h3>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                <span className="font-medium text-slate-700 dark:text-slate-300">Westminster Kennel Club Dog Show</span>
                <span className="text-slate-300">•</span>
                <span>Feb 12-14, 2024</span>
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"><Icons.Phone className="w-5 h-5" /></button>
            <button className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"><Icons.MoreVertical className="w-5 h-5" /></button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6 custom-scrollbar bg-slate-50/50 dark:bg-slate-900">
          <div className="flex justify-center">
            <span className="px-3 py-1 bg-slate-200/50 dark:bg-slate-800 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-widest">Today</span>
          </div>

          <div className="flex gap-3 max-w-[80%]">
            <div className="bg-slate-200 rounded-full size-8 shrink-0 bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/100/100?random=1')" }}></div>
            <div>
              <div className="bg-white dark:bg-slate-800 p-3 rounded-xl shadow-sm border border-slate-200/50 dark:border-slate-700">
                <p className="text-sm leading-relaxed">Hi Alex! I'm interested in booking you for the Westminster show. I have a Golden Retriever, "Ch. Stormy's Midnight Run", competing in the Best of Breed class.</p>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 ml-1">10:42 AM</span>
            </div>
          </div>

          <div className="flex gap-3 max-w-[80%] self-end flex-row-reverse">
            <div className="bg-primary text-white rounded-full size-8 shrink-0 flex items-center justify-center font-bold text-xs uppercase">AR</div>
            <div className="flex flex-col items-end">
              <div className="bg-primary text-white p-3 rounded-xl shadow-md">
                <p className="text-sm leading-relaxed">Hello Sarah! I'd love to help. I'm familiar with Midnight Run, he's a fantastic specimen. I have availability for those dates.</p>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 mr-1">10:44 AM</span>
            </div>
          </div>

          <div className="flex items-center gap-4 py-2">
            <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800"></div>
            <div className="flex items-center gap-2 text-slate-500">
              <Icons.FileText className="w-3 h-3" />
              <span className="text-[11px] font-medium italic">Alex updated the Inquiry Terms</span>
            </div>
            <div className="h-px flex-1 bg-slate-200 dark:bg-slate-800"></div>
          </div>
        </div>

        <footer className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-xl px-4 py-2">
            <button className="p-1 text-slate-500 hover:text-primary transition-colors"><Icons.Paperclip className="w-5 h-5" /></button>
            <input className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2" placeholder="Type your message..." type="text" />
            <button className="p-2 bg-primary text-white rounded-lg flex items-center justify-center hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
              <Icons.Send className="w-5 h-5" />
            </button>
          </div>
        </footer>
      </section>

      {/* Right Summary Sidebar */}
      <aside className="hidden xl:flex w-80 border-l border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex-col shrink-0 p-5 gap-6">
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Booking Summary</h3>
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-primary/10 text-primary p-2 rounded-lg"><Icons.Dog className="w-5 h-5" /></div>
              <div>
                <p className="text-xs text-slate-500">Subject Dog</p>
                <p className="text-sm font-bold">Ch. Midnight Run</p>
              </div>
            </div>
            <div className="space-y-4 mb-6">
              <div className="flex items-start gap-3">
                <Icons.Calendar className="w-4 h-4 text-slate-400" />
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">Event</p>
                  <p className="text-xs font-semibold">Westminster Dog Show</p>
                  <p className="text-[11px] text-slate-400 italic">Feb 12-14, 2024</p>
                </div>
              </div>
            </div>
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs text-slate-500">Status</span>
                <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold uppercase">Pending Confirmation</span>
              </div>
              <button className="w-full bg-primary text-white py-2.5 rounded-lg text-sm font-bold shadow-md hover:bg-primary/90 transition-all flex items-center justify-center gap-2">
                <Icons.ShieldCheck className="w-4 h-4" /> Confirm Booking
              </button>
            </div>
          </div>
        </div>
        <div className="bg-primary/5 rounded-xl p-4 border border-primary/10 mt-auto">
          <div className="flex items-center gap-2 text-primary mb-2">
            <Icons.ShieldCheck className="w-5 h-5" />
            <p className="text-[10px] font-bold uppercase tracking-widest">Trust Guarantee</p>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
            Bookings through HandlerHub include automated insurance coverage and dispute mediation.
          </p>
        </div>
      </aside>
    </div>
  );
};

export default MessagingPage;
