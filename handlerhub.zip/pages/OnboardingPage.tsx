
import React from 'react';
import { Icons } from '../constants';

const OnboardingPage: React.FC = () => {
  return (
    <main className="flex-1 flex justify-center py-12 px-6 animate-fade-in">
      <div className="w-full max-w-[720px] flex flex-col gap-8">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">Step 1 of 4</span>
            <span className="text-sm font-medium text-gray-500 dark:text-gray-400">25% Complete</span>
          </div>
          <div className="h-2 w-full bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: '25%' }}></div>
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">Professional Details</h1>
          <p className="text-gray-500 dark:text-gray-400 text-lg">Help exhibitors find you by listing your expertise and credentials.</p>
        </div>

        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-xl p-8">
          <form className="space-y-8">
            <div className="space-y-3">
              <label className="block text-base font-semibold text-gray-900 dark:text-gray-100">
                Years of Professional Experience
              </label>
              <div className="relative max-w-[200px]">
                <input 
                  className="w-full h-12 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-4 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all" 
                  placeholder="e.g. 5" 
                  type="number" 
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">Years</span>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">Include your time as both an assistant and a lead handler.</p>
            </div>

            <div className="space-y-3">
              <label className="block text-base font-semibold text-gray-900 dark:text-gray-100">
                Kennel Club Affiliations
              </label>
              <textarea 
                className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all resize-none" 
                placeholder="e.g. AKC, UKC, Canadian Kennel Club, PHA" 
                rows={3}
              />
              <p className="text-sm text-gray-500 dark:text-gray-400">List the professional organizations you are currently a member of.</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-base font-semibold text-gray-900 dark:text-gray-100">Breed Specialties</label>
                <span className="text-xs font-medium text-gray-400 uppercase">Select all that apply</span>
              </div>
              <div className="relative">
                <Icons.Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input className="w-full h-12 pl-12 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-primary outline-none transition-all" placeholder="Search breeds..." type="text" />
              </div>
              <div className="flex flex-wrap gap-2 pt-2">
                {['Golden Retriever', 'German Shepherd', 'Standard Poodle'].map(breed => (
                  <div key={breed} className="flex items-center gap-1.5 bg-primary/10 border border-primary/20 text-primary px-3 py-1.5 rounded-full text-sm font-medium">
                    {breed}
                    <button type="button" className="hover:text-primary-dark opacity-60">×</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
              <button className="px-6 py-3 text-sm font-semibold text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors" type="button">
                Back
              </button>
              <button className="bg-primary hover:bg-primary/90 text-white px-10 py-3 rounded-lg font-bold shadow-lg shadow-primary/20 transition-all flex items-center gap-2" type="submit">
                Continue
                <Icons.ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
};

export default OnboardingPage;
