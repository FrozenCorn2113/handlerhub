
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Icons, SAMPLE_HANDLERS } from '../constants';

const ProfilePage: React.FC = () => {
  const { id } = useParams();
  const handler = SAMPLE_HANDLERS.find(h => h.id === id) || SAMPLE_HANDLERS[1];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
      {/* Hero Header */}
      <div className="relative rounded-2xl overflow-hidden mb-8 border border-slate-200 dark:border-slate-800 h-64 sm:h-80 shadow-lg">
        <div 
          className="absolute inset-0 bg-cover bg-center" 
          style={{ 
            backgroundImage: "linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.6)), url('https://lh3.googleusercontent.com/aida-public/AB6AXuCChnFaGb2lObe0pdDCegfKbxM2AClYkpb2b-r-1zfZXWiyrTt9NKLpUOLSQV1uXBTyY_tcykjErs9KPeQJkHCrDVR1OTy6WXEe3oDTB48mYBeF_H8UlbVnFVZBncOMCPWWSVdGnljEAhdgWNGVt2ZBxYn6WJ7RxOpc2u_mxUIHotvc2UKd05g0Ta5cYj7miygxM4Lo8sttDZ_SpD1h2bhZAj1JPQiMIWMHfM2885rqmykd8diBfnNAsCwxmzzqiZgAVf0-eYypEQ')" 
          }}
        />
        <div className="absolute bottom-0 left-0 w-full p-6 sm:p-10 flex flex-col sm:flex-row items-end sm:items-center gap-6">
          <div className="relative">
            <div className="h-24 w-24 sm:h-32 sm:w-32 rounded-full border-4 border-white dark:border-background-dark bg-cover bg-center shadow-2xl" 
                 style={{ backgroundImage: `url('${handler.avatar}')` }} 
            />
            <div className="absolute bottom-1 right-1 bg-primary text-white p-1 rounded-full border-2 border-white dark:border-background-dark">
              <Icons.ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="flex-1 text-white pb-2">
            <h1 className="text-3xl font-bold tracking-tight">{handler.name}</h1>
            <p className="text-white/90 font-medium">{handler.title}</p>
            <div className="flex items-center gap-4 mt-2 text-sm text-white/80">
              <span className="flex items-center gap-1"><Icons.MapPin className="w-4 h-4" /> {handler.region}, USA</span>
              <span className="flex items-center gap-1"><Icons.Star className="w-4 h-4 fill-current" /> {handler.rating} ({handler.reviewsCount} reviews)</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="text-2xl font-bold text-primary">{handler.yearsExperience}+</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Years Exp.</div>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="text-2xl font-bold text-primary">{handler.breedsCount}</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Breeds</div>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-center">
              <div className="text-2xl font-bold text-primary">{handler.winsCount}+</div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Wins/Titles</div>
            </div>
          </div>

          {/* About */}
          <section className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <h2 className="text-xl font-bold mb-4">About {handler.name.split(' ')[0]}</h2>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{handler.description}</p>
          </section>

          {/* Availability */}
          <section className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Availability</h2>
              <div className="flex gap-2">
                <button className="p-1 border rounded hover:bg-slate-50"><Icons.ChevronLeft className="w-4 h-4" /></button>
                <button className="p-1 border rounded hover:bg-slate-50"><Icons.ChevronRight className="w-4 h-4" /></button>
              </div>
            </div>
            {/* Calendar Grid (Simulated) */}
            <div className="grid grid-cols-7 gap-1 text-center">
              {['M','T','W','T','F','S','S'].map(d => <div key={d} className="text-xs font-bold text-slate-400 mb-2">{d}</div>)}
              {[...Array(14)].map((_, i) => (
                <div key={i} className={`h-10 flex items-center justify-center text-sm font-medium rounded ${i > 7 ? 'bg-primary text-white cursor-pointer' : 'text-slate-400'}`}>
                  {i + 28 > 30 ? (i + 28) - 30 : i + 28}
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1"><span className="w-3 h-3 bg-red-100 rounded"></span> Booked</div>
              <div className="flex items-center gap-1"><span className="w-3 h-3 bg-primary rounded"></span> Open (National Cluster)</div>
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border-2 border-primary/20 shadow-xl">
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-3xl font-bold">$125</span>
                <span className="text-slate-500 dark:text-slate-400 text-sm font-medium">/ per class</span>
              </div>
              <div className="space-y-3">
                <Link to="/messaging" className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-2">
                  <Icons.Calendar className="w-4 h-4" /> Request Booking
                </Link>
                <Link to="/messaging" className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-2">
                  <Icons.Mail className="w-4 h-4" /> Send Message
                </Link>
              </div>
              <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Response Time</span>
                  <span className="font-semibold text-green-600">~ 2 hours</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-500 dark:text-slate-400">Travel Distance</span>
                  <span className="font-semibold">Up to 500 mi</span>
                </div>
              </div>
              <div className="mt-6 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg flex items-start gap-3">
                <Icons.Info className="text-primary w-5 h-5 flex-shrink-0" />
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                  Booking requests are subject to confirmation. Rates exclude travel expenses and grooming fees if applicable.
                </p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400 mb-4 tracking-wider">Base Region</h3>
              <div className="h-32 bg-slate-200 dark:bg-slate-800 rounded-lg mb-4 flex items-center justify-center">
                <Icons.MapPin className="w-8 h-8 text-primary" />
              </div>
              <p className="text-sm font-medium text-center">Based in Hartford, CT</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
