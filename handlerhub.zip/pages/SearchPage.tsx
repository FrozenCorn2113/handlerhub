
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Icons, SAMPLE_HANDLERS } from '../constants';
import AIMatchmaker from '../components/AIMatchmaker';

const SearchPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('Highest Rated');

  const filteredHandlers = useMemo(() => {
    return SAMPLE_HANDLERS.filter(handler => {
      const matchesSearch = handler.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           handler.specialties.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesGroup = selectedGroups.length === 0 || 
                          selectedGroups.some(group => handler.specialties.includes(group) || handler.level.includes(group));
      return matchesSearch && matchesGroup;
    }).sort((a, b) => {
      if (sortBy === 'Highest Rated') return b.rating - a.rating;
      if (sortBy === 'Most Experienced') return b.yearsExperience - a.yearsExperience;
      return 0;
    });
  }, [searchQuery, selectedGroups, sortBy]);

  const toggleGroup = (group: string) => {
    setSelectedGroups(prev => 
      prev.includes(group) ? prev.filter(g => g !== group) : [...prev, group]
    );
  };

  return (
    <div className="max-w-[1440px] mx-auto px-6 lg:px-12 py-8 flex flex-col md:flex-row gap-8 relative">
      {/* Sidebar Filters */}
      <aside className="w-full md:w-64 shrink-0 flex flex-col gap-8">
        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">Filters</h3>
          <div className="mb-6">
            <label className="flex items-center gap-2 text-sm font-bold mb-3">
              <Icons.Search className="w-4 h-4" /> Keyword
            </label>
            <input 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-sm rounded-lg border-slate-200 dark:border-slate-800 dark:bg-slate-900 focus:border-primary focus:ring-primary" 
              placeholder="Breed, name..." 
              type="text" 
            />
          </div>
          <div className="mb-6">
            <label className="flex items-center gap-2 text-sm font-bold mb-3">
              <Icons.Dog className="w-4 h-4" /> Specialist Groups
            </label>
            <div className="space-y-2">
              {['Sporting', 'Working', 'Herding', 'Master Handler'].map(group => (
                <label key={group} className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={selectedGroups.includes(group)}
                    onChange={() => toggleGroup(group)}
                    className="rounded text-primary focus:ring-primary dark:bg-slate-900 border-slate-300 dark:border-slate-700" 
                  />
                  <span className="text-sm group-hover:text-primary transition-colors">{group}</span>
                </label>
              ))}
            </div>
          </div>
          <button 
            onClick={() => {setSelectedGroups([]); setSearchQuery('');}}
            className="w-full py-2.5 text-sm font-bold text-slate-600 dark:text-slate-400 bg-slate-200/50 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
          >
            Reset Filters
          </button>
        </div>
        
        <div className="hidden md:block p-4 rounded-xl bg-primary/10 border border-primary/20">
          <h4 className="text-primary font-bold text-sm mb-1">Expert Advice</h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-3">
            Not sure who to pick? Our AI assistant can help you find the perfect match based on your breed's specific needs.
          </p>
          <div className="flex items-center gap-1 text-xs font-black text-primary animate-pulse">
            TRY AI MATCHMAKER <Icons.ChevronRight className="w-3 h-3" />
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Professional Handlers</h1>
            <p className="text-slate-500 mt-1 font-medium">{filteredHandlers.length} experts available for your next show</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-500 font-medium">Sort by:</span>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm font-bold bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 rounded-lg focus:ring-primary py-1.5 pl-3 pr-8"
            >
              <option>Highest Rated</option>
              <option>Most Experienced</option>
            </select>
          </div>
        </div>

        {filteredHandlers.length > 0 ? (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {filteredHandlers.map(handler => (
              <div key={handler.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row gap-5 hover:shadow-lg transition-shadow group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3">
                  <span className="bg-primary/10 text-primary text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest">{handler.level}</span>
                </div>
                <div className="shrink-0 flex justify-center sm:block">
                  <div className="size-24 rounded-full border-2 border-primary/20 p-1">
                    <img className="w-full h-full object-cover rounded-full" src={handler.avatar} alt={handler.name} />
                  </div>
                </div>
                <div className="flex-1 flex flex-col">
                  <div className="mb-1">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">{handler.name}</h3>
                    <div className="flex items-center gap-1 text-yellow-500 mb-1">
                      {[...Array(5)].map((_, i) => <Icons.Star key={i} className={`w-3 h-3 ${i < Math.floor(handler.rating) ? 'fill-current' : ''}`} />)}
                      <span className="text-xs font-bold text-slate-500 ml-1">{handler.rating} ({handler.reviewsCount} reviews)</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-500 text-sm mb-3 font-medium">
                    <Icons.MapPin className="w-4 h-4" />
                    {handler.region} • {handler.location}
                  </div>
                  <div className="mt-auto flex flex-wrap gap-2">
                    {handler.specialties.map(spec => (
                      <span key={spec} className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-300">{spec}</span>
                    ))}
                  </div>
                  <div className="mt-5">
                    <Link 
                      to={`/profile/${handler.id}`} 
                      className="block w-full text-center py-2 bg-primary text-white text-sm font-bold rounded-lg hover:brightness-110 transition-all active:scale-[0.98]"
                    >
                      View Profile
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center">
            <div className="bg-slate-100 dark:bg-slate-800 size-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icons.Search className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-bold mb-1">No handlers found</h3>
            <p className="text-slate-500 text-sm mb-6">Try adjusting your filters or ask our AI scout for help.</p>
            <button 
              onClick={() => {setSelectedGroups([]); setSearchQuery('');}}
              className="text-primary font-bold hover:underline"
            >
              Clear all filters
            </button>
          </div>
        )}

        {filteredHandlers.length > 0 && (
          <div className="mt-12 flex items-center justify-center gap-2">
            <button className="size-10 flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800">
              <Icons.ChevronLeft className="w-4 h-4" />
            </button>
            <button className="size-10 flex items-center justify-center rounded-lg bg-primary text-white font-bold">1</button>
            <button className="size-10 flex items-center justify-center rounded-lg border border-slate-200 dark:border-slate-800">
              <Icons.ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>

      <AIMatchmaker />
    </div>
  );
};

export default SearchPage;
